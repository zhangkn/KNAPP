//
//  KNCocoaTouchStaticLibrary.m
//  KNCocoaTouchStaticLibrary
//
//  Created by devzkn on 29/06/2017.
//  Copyright © 2017 hisun. All rights reserved.
//

#import "KNCocoaTouchStaticLibrary.h"

@implementation KNCocoaTouchStaticLibrary

@end
