//
//  KNTestWebViewController.h
//  KNUIWebViewWithFileInput
//
//  Created by devzkn on 27/03/2017.
//  Copyright © 2017 hisun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KNBaseWebViewController.h"
@interface KNTestWebViewController :KNBaseWebViewController

@end
