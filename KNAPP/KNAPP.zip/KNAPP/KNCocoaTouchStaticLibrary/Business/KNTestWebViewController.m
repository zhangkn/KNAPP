//
//  KNTestWebViewController.m
//  KNUIWebViewWithFileInput
//
//  Created by devzkn on 27/03/2017.
//  Copyright © 2017 hisun. All rights reserved.
//

#import "KNTestWebViewController.h"

@interface KNTestWebViewController ()

@end

@implementation KNTestWebViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
