//
//  IPLoadingTool.h
//  iCloudPay
//
//  Created by devzkn on 24/03/2017.
//  Copyright © 2017 Kevin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface IPLoadingTool : NSObject



+(void)StartLoading;

+(void)StopLoading;
@end
